export default [
    {
      id: 0,
      name: 'E commrce App UI Kit',
      price: 10,
      image: '/pc.png',   // /sample.png
      user: {
        image: '/pc.png',  // /user.png
        name: 'Tubeguruji'
      }
    },
    {
      id: 1,
      name: 'E commrce App UI Kit',
      price: 10,
      image: '/pc.png',
      user: {
        image: '/pc.png',
        name: 'Tubeguruji'
      }
    },
    {
      id: 2,
      name: 'E commrce App UI Kit',
      price: 10,
      image: '/pc.png',
      user: {
        image: '/pc.png',
        name: 'Tubeguruji'
      }
    },
    {
      id: 3,
      name: 'E commrce App UI Kit',
      price: 10,
      image: '/pc.png',
      user: {
        image: '/pc.png',
        name: 'Tubeguruji'
      }
    }
  ];
  