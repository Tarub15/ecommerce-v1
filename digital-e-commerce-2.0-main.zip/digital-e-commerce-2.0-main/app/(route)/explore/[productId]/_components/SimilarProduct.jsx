import React from 'react'

function SimilarProduct({category}) {
  return (
    <div>
      SimilarProducts
    </div>
  )
}

export default SimilarProduct
